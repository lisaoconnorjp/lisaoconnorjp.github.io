# Algorithmic Image Classifier

## Author

Thomas O'Connor
Adaptation of Machine Learning Coursework
Spring 2024 \* Python3

## Contents

1. Machine Learning Assignment 7

- TOConnor_A7_NN.py
  My implementation of a basic, general purpose image classifier in accordance with Machine Learning Assignment 7. Can be adapted to any images when trained on an appropriately large and accurately labeled dataset.
- TOConnor_ML_A7.pdf
  My report to accompany the neural network model. Includes summary, description and insights into the development process.

2. Affliction Severity Classifier

- TOConnor_CNN.ipynb
  Jupyter notebook including cnn implementation and robust descriptions of core concepts. Adapted from my general purpose image classifier, used as reference material in professor Delhommelle's graduate courses. Similar performance when compared to VGG19 (pre-trained image classifier with 19 layers) 0.76 accuracy and 0.77 accuracy respectively.
  Upload and test individual images for local classification of affliction severity.

## Dataset Provenance

For CIFAR-10 : follow relevant readme documentation <http://www.cs.toronto.edu/~kriz/cifar.html>
For affliction severity model : trained on Kaggle database <https://www.kaggle.com/datasets/sergio814/dermoscopy-images/data>
Active and updated as of 01/2025

### Acknowledgements

CIFAR
NumPy
MatPlotLib
Seaborn
Tensorflow/Keras

Professor Chris Geggis : UMass Lowell
Professor Jerome Delhommelle : UMass Lowell
