# Monte Carlo Stock Market Simulator

## Author

Thomas O'Connor
Adaptation of Machine Learning Coursework
Spring 2024 \* Python3

## Contents

Interactive_Trend_Sim.py
stock_simulation.gif
stock_simulation.png
TOConnor_ML_A4_report.pdf

## Description

Leverages the following principles:
Drift
Volatility
Geometric Brownian Motion formula (normal distribution)

### Acknowledgements

Yahoo Finance
NumPy
MatPlotLib
TQDM
Professor Chris Geggis : UMass Lowell
